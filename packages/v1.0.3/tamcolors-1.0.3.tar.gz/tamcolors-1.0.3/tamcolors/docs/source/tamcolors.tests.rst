tamcolors.tests package
=======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   tamcolors.tests.tam
   tamcolors.tests.tam_basic
   tamcolors.tests.tam_io
   tamcolors.tests.tam_tools

Submodules
----------

tamcolors.tests.all\_tests module
---------------------------------

.. automodule:: tamcolors.tests.all_tests
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: tamcolors.tests
   :members:
   :undoc-members:
   :show-inheritance:
