tamcolors.tam\_io package
=========================

Submodules
----------

tamcolors.tam\_io.any\_tam module
---------------------------------

.. automodule:: tamcolors.tam_io.any_tam
   :members:
   :undoc-members:
   :show-inheritance:

tamcolors.tam\_io.io\_tam module
--------------------------------

.. automodule:: tamcolors.tam_io.io_tam
   :members:
   :undoc-members:
   :show-inheritance:

tamcolors.tam\_io.tam\_buffer module
------------------------------------

.. automodule:: tamcolors.tam_io.tam_buffer
   :members:
   :undoc-members:
   :show-inheritance:

tamcolors.tam\_io.tam\_colors module
------------------------------------

.. automodule:: tamcolors.tam_io.tam_colors
   :members:
   :undoc-members:
   :show-inheritance:

tamcolors.tam\_io.tam\_keys module
----------------------------------

.. automodule:: tamcolors.tam_io.tam_keys
   :members:
   :undoc-members:
   :show-inheritance:

tamcolors.tam\_io.uni\_tam module
---------------------------------

.. automodule:: tamcolors.tam_io.uni_tam
   :members:
   :undoc-members:
   :show-inheritance:

tamcolors.tam\_io.win\_tam module
---------------------------------

.. automodule:: tamcolors.tam_io.win_tam
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: tamcolors.tam_io
   :members:
   :undoc-members:
   :show-inheritance:
