tamcolors.tam\_c package
========================

Module contents
---------------

.. automodule:: tamcolors.tam_c
   :members:
   :undoc-members:
   :show-inheritance:
