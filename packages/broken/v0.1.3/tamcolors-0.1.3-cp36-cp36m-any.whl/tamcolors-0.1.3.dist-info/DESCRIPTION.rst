

About tamcolors
===============

     tamcolors lets you change terminal colors.


Color Table
===========

    -1 = None
    0  = "Black"       8  = "Gray"
    1  = "Blue"        9  = "Light Blue"
    2  = "Green"       10 = "Light Green"
    3  = "Aqua"        11 = "Light Aqua"
    4  = "Red"         12 = "Light Red"
    5  = "Purple"      13 = "Light Purple"
    6  = "Yellow"      14 = "Light Yellow"
    7  = "White"       15 = "Bright White"

About Color Table
=================

    tamcolors table is not case-sensitive.

tamcolors Main Functions
========================

printc("hello", (2,6))
inputc(">>> ", ("aqua", -1))


