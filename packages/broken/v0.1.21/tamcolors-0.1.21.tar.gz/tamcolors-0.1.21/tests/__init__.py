from test import test_tamcolors
from test import test_printc
from test import test_inputc
from test import test_textBuffer

if __name__ == "__main__":
    test_tamcolors.test()
    
