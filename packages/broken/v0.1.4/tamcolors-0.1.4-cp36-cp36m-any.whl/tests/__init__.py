from test import test_tamcolors

if __name__ == "__main__":
    test_tamcolors.test()
    
