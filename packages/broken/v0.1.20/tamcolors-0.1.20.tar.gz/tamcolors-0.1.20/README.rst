
+++++++++++++++
About tamcolors
+++++++++++++++

tamcolors lets you change terminal colors for Mac, Linux and Windows.

.. image:: https://lh5.googleusercontent.com/r-2qmoWJXitqe8jFRYvgrGhnkwLUrWrxnIgShZcjPFr8nunZDbVQcHaLR_kdl2aHBbeI0zM-WDVNZVRIy2FK=w2560-h1404-rw
.. image:: https://lh3.googleusercontent.com/xnnQmAAH7GH6EtHdKTC-f31-12QM2tW-oIERwxwqJ5xtcUyVlrkFDA7d5pkGYhnpAimJEbIZGK69vk7y5uFI=w2560-h1404-rw
.. image:: https://lh5.googleusercontent.com/gvyJ1cyL0efjmLK3O74chrplovTUSO4qlKJUbcX2RxFsrPnATrMvy21v9O1bIhSHDtnN-b0Y92NSiwlh-4cn=w2560-h1404-rw

Color Table:

    +-------------+------+---------------+
    |Colors       | Way1 |Way2           |
    +=============+======+===============+
    |Default      | -1   |None           |
    +-------------+------+---------------+
    |Black        | 0    |"Black"        |
    +-------------+------+---------------+
    |Blue         | 1    |"Blue"         |
    +-------------+------+---------------+
    |Green        | 2    |"Green"        |
    +-------------+------+---------------+
    |Aqua         | 3    |"Aqua"         |
    +-------------+------+---------------+
    |Red          | 4    |"Red"          |
    +-------------+------+---------------+
    |Purple       | 5    |"Purple"       |
    +-------------+------+---------------+
    |Yellow       | 6    |"Yellow"       |
    +-------------+------+---------------+
    |White        | 7    |"White"        |
    +-------------+------+---------------+
    |Gray         | 8    |"Gray"         |
    +-------------+------+---------------+
    |Light Blue   | 9    |"Light Blue"   |
    +-------------+------+---------------+
    |Light Green  | 10   |"Light Green"  |
    +-------------+------+---------------+
    |Light Aqua   | 11   |"Light Aqua"   |
    +-------------+------+---------------+
    |Light Red    | 12   |"Light Red"    |
    +-------------+------+---------------+
    |Light Purple | 13   |"Light Purple" |
    +-------------+------+---------------+
    |Light Yellow | 14   |"Light Yellow" |
    +-------------+------+---------------+
    |Bright White | 15   |"Bright White" |
    +-------------+------+---------------+
    
++++++
printc
++++++

.. code:: python

    from tamcolors import*

    #printc(*value, sameColor = False, sep = ' ', end = '\n', bypassCTT = False)
    
    printc("I'm Thinking 101", (11, -1))
    printc("French Bread 404", (4, None), "Sing", ("Light Aqua", "red"))
    printc("C","H","4","4","D",(11,15), sameColor = True)
    
.. image:: https://lh3.googleusercontent.com/4FoEuUansjiJoKRo8cRml5vPrzUVXxF7A5zo0_vRG44HKj4kbzGM7ByLzrsmNPU2Cl1zIbwaxDrS3n5oSixA=w2560-h1404-rw

++++++
inputc
++++++

.. code:: python

    from tamcolors import*

    #inputc(value, color, bypassCTT = False)
    
    inputc(">>> ", (3, 8))

.. image:: https://lh6.googleusercontent.com/BujJylzBSHg9SuFr_Az2IOXQsfgnHHKsb0Nja5Audh3NcsvnmOOv3hKkCdUXOeGoBu8vB4r63WfoorxSnUkE=w2547-h1375-rw  
    
++++++++++
textBuffer
++++++++++

.. code:: python

    from tamcolors import*

    title = textBuffer('#', (4, 7), 110, 28)
    title.place(1, 1, 'tamcolors', background = 9)        
    title.printt()

    #textBuffer(self, value, color, w, h)
    #new(self, value, color, w, h)
    #fill(self, value = "NC", foreground = "NC", background = "NC")
    #place(self, x, y, value = "NC", foreground = "NC", background = "NC")
    #printt(self)
    #drawOn(self, buffer2, x, y)

.. image:: https://lh3.googleusercontent.com/Q6wep8y3Ib3pExyQ8Je8ng4HfVnY_5m2VeqsiX6allw81S_SwZgie7p1BTOmuixkbdKDNW61q7Uhzg5rPM1W=w2547-h1375-rw



    
    


    
    
