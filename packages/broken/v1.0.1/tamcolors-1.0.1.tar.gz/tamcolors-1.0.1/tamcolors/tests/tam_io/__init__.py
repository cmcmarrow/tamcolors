from . import io_tam_tests
from . import any_tam_tests
from . import uni_tam_tests
from . import win_tam_tests

__all__ = ("io_tam_tests",
           "any_tam_tests",
           "uni_tam_tests",
           "win_tam_tests")
