from . import tam_buffer_tests
from . import tam_colors_tests
from . import tam_keys_tests
from . import tam_loop_tests
from . import tam_loop_test_tests
from . import tam_standard_tests


__all__ = ("tam_buffer_tests",
           "tam_colors_tests",
           "tam_keys_tests",
           "tam_loop_tests",
           "tam_loop_test_tests",
           "tam_standard_tests")
