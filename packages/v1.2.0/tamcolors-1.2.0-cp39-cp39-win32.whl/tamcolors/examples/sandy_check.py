from tamcolors import examples


def run():
    examples.rgb_color.run()
    examples.clouds.run()
    examples.colors.run()
    examples.basic.run()
    examples.icon.run()
