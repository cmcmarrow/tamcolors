from tamcolors.tests.all_tests import tests_main

if __name__ == "__main__":
    exit(int(not tests_main()))
