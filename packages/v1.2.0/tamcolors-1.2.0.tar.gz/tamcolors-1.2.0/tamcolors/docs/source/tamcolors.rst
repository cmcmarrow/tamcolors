tamcolors package
=================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   tamcolors.examples
   tamcolors.tam
   tamcolors.tam_basic
   tamcolors.tam_c
   tamcolors.tam_io
   tamcolors.tam_tools
   tamcolors.tests
   tamcolors.utils

Module contents
---------------

.. automodule:: tamcolors
   :members:
   :undoc-members:
   :show-inheritance:
