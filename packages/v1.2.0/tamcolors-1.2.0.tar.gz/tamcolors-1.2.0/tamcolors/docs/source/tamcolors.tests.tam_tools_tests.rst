tamcolors.tests.tam\_tools\_tests package
=========================================

Submodules
----------

tamcolors.tests.tam\_tools\_tests.tam\_color\_palette\_tests module
-------------------------------------------------------------------

.. automodule:: tamcolors.tests.tam_tools_tests.tam_color_palette_tests
   :members:
   :undoc-members:
   :show-inheritance:

tamcolors.tests.tam\_tools\_tests.tam\_fade\_tests module
---------------------------------------------------------

.. automodule:: tamcolors.tests.tam_tools_tests.tam_fade_tests
   :members:
   :undoc-members:
   :show-inheritance:

tamcolors.tests.tam\_tools\_tests.tam\_film\_tests module
---------------------------------------------------------

.. automodule:: tamcolors.tests.tam_tools_tests.tam_film_tests
   :members:
   :undoc-members:
   :show-inheritance:

tamcolors.tests.tam\_tools\_tests.tam\_key\_manager\_tests module
-----------------------------------------------------------------

.. automodule:: tamcolors.tests.tam_tools_tests.tam_key_manager_tests
   :members:
   :undoc-members:
   :show-inheritance:

tamcolors.tests.tam\_tools\_tests.tam\_list\_buffer\_tests module
-----------------------------------------------------------------

.. automodule:: tamcolors.tests.tam_tools_tests.tam_list_buffer_tests
   :members:
   :undoc-members:
   :show-inheritance:

tamcolors.tests.tam\_tools\_tests.tam\_menu\_tests module
---------------------------------------------------------

.. automodule:: tamcolors.tests.tam_tools_tests.tam_menu_tests
   :members:
   :undoc-members:
   :show-inheritance:

tamcolors.tests.tam\_tools\_tests.tam\_placing\_tests module
------------------------------------------------------------

.. automodule:: tamcolors.tests.tam_tools_tests.tam_placing_tests
   :members:
   :undoc-members:
   :show-inheritance:

tamcolors.tests.tam\_tools\_tests.tam\_print\_tests module
----------------------------------------------------------

.. automodule:: tamcolors.tests.tam_tools_tests.tam_print_tests
   :members:
   :undoc-members:
   :show-inheritance:

tamcolors.tests.tam\_tools\_tests.tam\_str\_tests module
--------------------------------------------------------

.. automodule:: tamcolors.tests.tam_tools_tests.tam_str_tests
   :members:
   :undoc-members:
   :show-inheritance:

tamcolors.tests.tam\_tools\_tests.tam\_text\_box\_tests module
--------------------------------------------------------------

.. automodule:: tamcolors.tests.tam_tools_tests.tam_text_box_tests
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: tamcolors.tests.tam_tools_tests
   :members:
   :undoc-members:
   :show-inheritance:
