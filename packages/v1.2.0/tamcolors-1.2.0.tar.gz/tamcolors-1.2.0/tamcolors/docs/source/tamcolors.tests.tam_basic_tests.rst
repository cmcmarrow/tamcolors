tamcolors.tests.tam\_basic\_tests package
=========================================

Submodules
----------

tamcolors.tests.tam\_basic\_tests.basic\_tests module
-----------------------------------------------------

.. automodule:: tamcolors.tests.tam_basic_tests.basic_tests
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: tamcolors.tests.tam_basic_tests
   :members:
   :undoc-members:
   :show-inheritance:
