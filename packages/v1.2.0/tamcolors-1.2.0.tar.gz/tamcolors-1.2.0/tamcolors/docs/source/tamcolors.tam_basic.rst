tamcolors.tam\_basic package
============================

Submodules
----------

tamcolors.tam\_basic.basic module
---------------------------------

.. automodule:: tamcolors.tam_basic.basic
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: tamcolors.tam_basic
   :members:
   :undoc-members:
   :show-inheritance:
