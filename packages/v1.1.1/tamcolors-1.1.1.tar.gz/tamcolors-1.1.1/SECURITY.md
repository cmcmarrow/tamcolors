# Security Policy

## Supported Versions

tamcolors will not patch older versions. The security bug will be patched in the next release.

## Reporting a Vulnerability

Please Email: Charles.McMarrow.4@gmail.com
Have `tamcolor Security Bug` in the header of your email. In your email please explain how to replicate the issues and why it is a security bug. It would be great if you add an example script as well. 
Then make an issue in github asking me to check my security email.

tamcolors will try to get back to you as soon as possible. If tamcolors deem it to be a Security bug It will start working on the patch right away.
