from . import tam_loop


"""
tam draws text with color to the terminal
tam can get key input from the terminal
tam supports
* Darwin
* Linux
* Windows
"""

__all__ = ("tam_loop",
           )
