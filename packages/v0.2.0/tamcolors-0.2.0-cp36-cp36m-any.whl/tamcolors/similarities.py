colorToText = False
colorToTextList = ["ժ", "փ", "բ", "ք", "դ", "ե", "ճ", "է",
                   "ը", "թ", "ժ", "ի", "ֆ", "խ", "ծ", "կ",
                   " "]

clearJumper = 0
