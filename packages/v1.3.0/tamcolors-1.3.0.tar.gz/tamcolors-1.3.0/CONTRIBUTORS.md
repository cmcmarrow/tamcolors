# tamcolors author
* Charles McMarrow, cmcmarrow, charles.mcmarrow.4@gmail.com

# tamcolors contributors
* Alia Rhoton, ,
* Alex Top, alextop99, alexandru.tp@gmail.com
