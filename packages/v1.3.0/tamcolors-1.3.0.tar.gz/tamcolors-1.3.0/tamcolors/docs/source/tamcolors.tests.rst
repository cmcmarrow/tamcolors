tamcolors.tests package
=======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   tamcolors.tests.tam_basic_tests
   tamcolors.tests.tam_io_tests
   tamcolors.tests.tam_tests
   tamcolors.tests.tam_tools_tests
   tamcolors.tests.tests_tests
   tamcolors.tests.utils_tests

Submodules
----------

tamcolors.tests.all\_tests module
---------------------------------

.. automodule:: tamcolors.tests.all_tests
   :members:
   :undoc-members:
   :show-inheritance:

tamcolors.tests.test\_multi\_task\_helper module
------------------------------------------------

.. automodule:: tamcolors.tests.test_multi_task_helper
   :members:
   :undoc-members:
   :show-inheritance:

tamcolors.tests.test\_utils module
----------------------------------

.. automodule:: tamcolors.tests.test_utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: tamcolors.tests
   :members:
   :undoc-members:
   :show-inheritance:
